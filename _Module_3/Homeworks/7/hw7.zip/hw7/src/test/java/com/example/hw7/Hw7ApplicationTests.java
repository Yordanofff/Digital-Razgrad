package com.example.hw7;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Hw7ApplicationTests {

	@Test
	void contextLoads() {
	}

}
