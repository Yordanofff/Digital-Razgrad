package com.example.homework11;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Homework11ApplicationTests {

	@Test
	void contextLoads() {
	}

}
