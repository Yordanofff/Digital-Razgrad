package com.example.homework11;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Homework11Application {

	public static void main(String[] args) {
		SpringApplication.run(Homework11Application.class, args);
	}

}
