package com.h19.h19;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class H19Application {

	public static void main(String[] args) {
		SpringApplication.run(H19Application.class, args);
	}

}
