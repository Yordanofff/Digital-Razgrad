public class Main {
    public static void main(String[] args) {
        System.out.println("Sorry but I've been quite busy and I didn't had enough time to do the second and the third task.");
        Task1.main();
    }
}