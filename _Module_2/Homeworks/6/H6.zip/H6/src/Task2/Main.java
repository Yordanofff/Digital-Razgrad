package Task2;
public class Main {
    //Направете клас Building с полета: адрес, дължина, ширина, височина, цена и има ли
    //соларни панели. С методи: paint(String color) - боядисвам, furnish(String furniture, int price).
    //Тези методи променят цената на сградата
    //● Направете интерфейс Gardening, който има методи: plant(String color) - за засаждане
    //и slantMeadow() - кося ливада
    //● Направете интерфейс Isolatiable, който има метод termalIsolation(String type) - за
    //поставяне на термоизолация
    //● Направете клас House, който наследява Building и има полета: вид покрив, размер на двор
    //(в квадратни метри). И имплементира интерфейсите Gardening и Isolatiable
    //● Направете клас Block, който наследява Building и има полета: брой етажи, има ли асансьор.
    //И имплементира интерфейса Isolatiable
    //● Използвайте подходящи нива на достъп, Getters и Setters и по 2 конструктора за всички
    //класове
    //● Създайте по 2 обекта на класовете House и Block, тествайте всички методи
    public static void main(String[] args) {
        // todo
    }
}
