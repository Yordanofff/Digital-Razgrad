package Task1;

public interface Payable {
    public void paySalary();
    public void payBonus(double amount);

}
