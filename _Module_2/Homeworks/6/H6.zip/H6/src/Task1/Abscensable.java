package Task1;

public interface Abscensable {
    public void paidLeave(int length);
    public void unpaidLeave(int length);
    public void sick(int length, String disease);

}
