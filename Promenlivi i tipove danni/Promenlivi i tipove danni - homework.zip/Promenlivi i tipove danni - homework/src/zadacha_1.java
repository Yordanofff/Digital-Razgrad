// Да се напише програма, която отпечатва правоъгълник от звездички със страни 3 на 5

public class zadacha_1 {
    public static void main(String[] args) {

        for (byte i = 1; i <= 3; i++) {

            System.out.println("*".repeat(5));

        }
    }
}